"use strict";

// IMPORTS ==================================================================================================
const { Router } = require("express");
const routes = {
	userRoutes: require("./user.routes"),
	postRoutes: require("./post.routes"),
	commentRoutes: require("./comment.routes"),
};

const router = new Router();

// API MIDDLE POINTS ========================================================================================
router.use("/user", routes.userRoutes);
router.use("/post", routes.postRoutes);
router.use("/comment", routes.commentRoutes);

// EXPORTS ==================================================================================================
module.exports = router;
