"use strict";

// IMPORTS ==================================================================================================
const { Router } = require("express");
const { postController } = require("../controllers");
const authentication = require("../middleware/authentication.middleware");

const router = new Router();

// API ROUTES ===============================================================================================

// All APIs written below needs to be authenticated with token.
router.post("/create", authentication, postController.createPost);
router.put("/update", authentication, postController.updatePost);
router.get("/get-all", authentication, postController.getAllPosts);
router.delete("/delete/:id", authentication, postController.deletePost);

// EXPORTS ==================================================================================================
module.exports = router;
