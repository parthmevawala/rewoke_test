"use strict";

// IMPORTS ==================================================================================================
const { Router } = require("express");
const { commentController } = require("../controllers");
const authentication = require("../middleware/authentication.middleware");

const router = new Router();

// API ROUTES ===============================================================================================

// All APIs written below needs to be authenticated with token.
router.post("/add", authentication, commentController.addComment);
router.put("/update", authentication, commentController.updateComment);
router.get("/get-all/:pid", authentication, commentController.getPostComments);
router.delete("/delete/:id", authentication, commentController.deleteComment);

// EXPORTS ==================================================================================================
module.exports = router;
