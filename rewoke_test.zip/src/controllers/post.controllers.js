"use strict";

// IMPORTS ==================================================================================================
const { postService } = require("../services");
const Connection = require("../includes/database_connection");

// CONTROLLERS ==============================================================================================
/**
 * List all posts - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const getAllPosts = async (req, res, next) => {
    const con = req._con;

    try {
        const response = await postService.getAllPosts(con);
        con.release();
        res.send(response);
    } catch (error) {
        con.release();
        next(error);
    }
};

/**
 * Create new post - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const createPost = async (req, res, next) => {
    const con = new Connection();
    await con.connect();
    await con.begin();

    try {
        const response = await postService.createPost(con, req.body.content, req._id);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

/**
 * Update post - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
 const updatePost = async (req, res, next) => {
    const con = new Connection();
    await con.connect();
    await con.begin();

    try {
        const response = await postService.updatePost(con, req.body);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

/**
 * Delete post - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const deletePost = async (req, res, next) => {
    const con = req._con;
    await con.begin();

    try {
        const response = await postService.deletePost(con, req.params.id);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

// EXPORTS ==================================================================================================
module.exports = {
    getAllPosts,
    createPost,
    updatePost,
    deletePost,
};
