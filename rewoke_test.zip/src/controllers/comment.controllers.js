"use strict";

// IMPORTS ==================================================================================================
const { commentService } = require("../services");
const Connection = require("../includes/database_connection");

// CONTROLLERS ==============================================================================================
/**
 * List all comments of a post - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const getPostComments = async (req, res, next) => {
    const con = req._con;

    try {
        const response = await commentService.getPostComments(con, req.params.pid);
        con.release();
        res.send(response);
    } catch (error) {
        con.release();
        next(error);
    }
};

/**
 * Add comment - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const addComment = async (req, res, next) => {
    const con = new Connection();
    await con.connect();
    await con.begin();

    try {
        const response = await commentService.addComment(con, req.body.content, req.body.pid, req._id);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

/**
 * Update comment - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
 const updateComment = async (req, res, next) => {
    const con = new Connection();
    await con.connect();
    await con.begin();

    try {
        const response = await commentService.updateComment(con, req.body);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

/**
 * Delete comment - controller
 * @param {object} req
 * @param {object} res
 * @param {object} next
 */
const deleteComment = async (req, res, next) => {
    const con = req._con;
    await con.begin();

    try {
        const response = await commentService.deleteComment(con, req.params.id);

        await con.commit();
        con.release();

        res.send(response);
    } catch (error) {
        await con.rollback();
        con.release();

        next(error);
    }
};

// EXPORTS ==================================================================================================
module.exports = {
    getPostComments,
    addComment,
    updateComment,
    deleteComment,
};
