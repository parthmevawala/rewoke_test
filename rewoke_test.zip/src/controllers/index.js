"use strict";

// EXPORTS ==================================================================================================
module.exports = {
    userController: require("./user.controllers"),
    postController: require("./post.controllers"),
    commentController: require("./comment.controllers"),
};
