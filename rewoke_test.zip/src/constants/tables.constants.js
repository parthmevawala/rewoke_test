"use strict";

// TABLE EXPORTS ============================================================================================
module.exports = {
    USERS: "tbl_users",
    POSTS: "tbl_posts",
    COMMENTS: "tbl_comments"
};
