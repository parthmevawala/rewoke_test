"use strict";

// IMPORTS ==================================================================================================
const { Pool } = require("pg");
const { databaseConfig } = require("../../config");
const { USERS, POSTS, COMMENTS } = require("../constants/tables.constants");

// Connection
const pool = new Pool({
	host: databaseConfig.host,
	port: databaseConfig.port,
	user: databaseConfig.user,
	password: databaseConfig.password,
	database: databaseConfig.database,
});

(async () => {
	try {
		const client = await pool.connect();
		// Creating tables if not exist
		await client.query(
			`
			CREATE TABLE IF NOT EXISTS ${USERS} (
				id SERIAL PRIMARY KEY,
				username VARCHAR,
				password VARCHAR,
				token VARCHAR,
				createdAt TIMESTAMP NOT NULL DEFAULT NOW()
			)
			`
		)
		await client.query(
			`
			CREATE TABLE IF NOT EXISTS ${POSTS} (
				id SERIAL PRIMARY KEY,
				uid INT REFERENCES ${USERS}(id),
				content VARCHAR,
				createdAt TIMESTAMP NOT NULL DEFAULT NOW()
			)
			`
		)
		await client.query(
			`
			CREATE TABLE IF NOT EXISTS ${COMMENTS} (
				id SERIAL PRIMARY KEY,
				uid INT REFERENCES ${USERS}(id),
				pid INT REFERENCES ${POSTS}(id),
				content VARCHAR,
				createdAt TIMESTAMP NOT NULL DEFAULT NOW()
			)
			`
		)
		client.release();
	} catch(error) {
		console.log(error);
	}
})();

class Connection {
	async connect() {
		this.client = await pool.connect();
	}

	release() {
		this.client.release();
	}

	async begin() {
		await this.client.query("BEGIN");
	}

	async commit() {
		await this.client.query("COMMIT");
	}

	async rollback() {
		await this.client.query("ROLLBACK");
	}

	async execute(query) {
		return this.client.query(query);
	}
}

module.exports = Connection;
