"use strict";

// IMPORTS ==================================================================================================
const { COMMENTS, USERS } = require("../constants/tables.constants");
const { ER_DATA_NOT_FOUND } = require("../constants/errors.constants");

// SERVICES ==================================================================================================
/**
 * Get all comments of a post - Service
 * @param {object} con
 * @param {string} pid
 * @returns
 */
const getPostComments = async (con, pid) => {
	const response = {
		message: "Comment added.",
	};

	// Insert operation
	const data = await con.execute(
		`
        SELECT c.content, c.createdAt, c.pid, c.id, c.uid, u.username 
        FROM ${COMMENTS} AS c, ${USERS} AS u 
        WHERE pid='${pid}' AND c.uid = u.id
        `,
	);

	response.data = data.rows || data;

	return response;
};

/**
 * Add new comment - Service
 * @param {object} con
 * @param {string} content
 * @param {string} pid
 * @param {string} uid
 * @returns
 */
const addComment = async (con, content, pid, uid) => {
	const response = {
		message: "Comment added.",
	};

	// Insert operation
	const data = await con.execute(
		`INSERT INTO ${COMMENTS} (content, pid, uid) VALUES ('${content}', '${pid}', '${uid}') RETURNING *`,
	);

	response.data = data.rows || data;

	return response;
};

/**
 * Update comment - Service
 * @param {object} con
 * @param {object} body
 * @returns
 */
const updateComment = async (con, body) => {
	const response = {
		message: "Comment updated.",
	};

	// Update operation
	const data = await con.execute(
		`UPDATE ${COMMENTS} SET content='${body.content}' WHERE id='${body.id}' RETURNING *`,
	);

	if (data.rowCount === 0) throw ER_DATA_NOT_FOUND("comment");

	response.data = data.rows || data;

	return response;
};

/**
 * Delete comment - service
 * @param {object} con
 * @param {string} id
 * @returns
 */
const deleteComment = async (con, id) => {
	const response = {
		message: "Comment delete successfully.",
		data: {},
	};
	const data = await con.execute(
		`DELETE FROM ${COMMENTS} WHERE id=${id} RETURNING id`,
	);

	if (data.rowCount) response.data = data.rows || data;

	return response;
};

// EXPORTS ==================================================================================================
module.exports = {
	getPostComments,
	addComment,
	updateComment,
	deleteComment,
};
