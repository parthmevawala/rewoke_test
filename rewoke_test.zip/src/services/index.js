"use strict";

// EXPORTS ==================================================================================================
module.exports = {
    userService: require("./user.services"),
    postService: require("./post.services"),
    commentService: require("./comment.services"),
};
