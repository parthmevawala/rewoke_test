"use strict";

// IMPORTS ==================================================================================================
const { POSTS, USERS } = require("../constants/tables.constants");
const {
	ER_DATA_NOT_FOUND,
} = require("../constants/errors.constants");

// SERVICES ==================================================================================================
/**
 * List all posts - Service
 * @param {object} con
 * @returns
 */
const getAllPosts = async (con) => {
	const data = await con.execute(`SELECT p.id, p.content, p.createdAt, p.uid, u.username as createdBy FROM ${POSTS} AS p, ${USERS} AS u WHERE p.uid = u.id ORDER BY p.id ASC`);

	return {
		data: data.rows || data,
		message: "Posts listed.",
	};
};

/**
 * Create new post - Service
 * @param {object} con
 * @param {string} content
 * @param {string} id
 * @returns
 */
const createPost = async (con, content, uid) => {
	const response = {
		message: "Post created.",
	};

	// Insert operation
	const data = await con.execute(
		`INSERT INTO ${POSTS} (content, uid) VALUES ('${content}', '${uid}') RETURNING *`,
	);

	response.data = data.rows || data;

	return response;
};

/**
 * Update post - Service
 * @param {object} con
 * @param {object} body
 * @returns
 */
 const updatePost = async (con, body) => {
	const response = {
		message: "Post updated.",
	};

	// Update operation
	const data = await con.execute(
		`UPDATE ${POSTS} SET content='${body.content}' WHERE id=${body.id} RETURNING *`,
	);

    if(data.rowCount === 0) throw ER_DATA_NOT_FOUND("post");

	response.data = data.rows || data;

	return response;
};

/**
 * Delete post - service
 * @param {object} con
 * @param {string} id
 * @returns
 */
const deletePost = async (con, id) => {
	const response = {
		message: "Post delete successfully.",
		data: {},
	};
	const data = await con.execute(
		`DELETE FROM ${POSTS} WHERE id=${id} RETURNING id`,
	);

    if(data.rowCount)
	response.data = data.rows || data;

	return response;
};

// EXPORTS ==================================================================================================
module.exports = {
    getAllPosts,
    createPost,
    updatePost,
    deletePost,
};
